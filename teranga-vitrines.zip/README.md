# Teranga Vitrines — plateforme SaaS multi-boutiques

Vitrines e-commerce pour les commerces de Dakar et d'Afrique de l'Ouest.
Livrable : **`index.html`** (application complète, un seul fichier) + **`_headers`** (sécurité Cloudflare Pages).

## Déploiement

1. Cloudflare Pages → *Créer un projet* → *Téléversement direct* → déposez le dossier contenant `index.html` et `_headers`.
2. Aucune commande de build. Le site fonctionne aussi en local : `python3 -m http.server` dans le dossier, puis http://localhost:8000.

### Recalculer l'empreinte CSP (après toute modification du JavaScript)

Le `Content-Security-Policy` autorise le script principal par son empreinte SHA-256 (pas de `'unsafe-inline'` pour les scripts).
Si vous modifiez le `<script>` de `index.html`, recalculez-la et remplacez la valeur `'sha256-…'` dans `_headers` :

```bash
python3 -c "import re,hashlib,base64;s=open('index.html',encoding='utf-8').read();m=re.search(r'<script>(.*?)</script>',s,re.S).group(1);print(\"'sha256-\"+base64.b64encode(hashlib.sha256(m.encode()).digest()).decode()+\"'\")"
```

Si l'empreinte ne correspond pas, la page reste bloquée sur le squelette de chargement et la console affiche une violation CSP.

## Guide de test rapide

Ouvrez le site, puis **Espace pro** (en haut à droite) ou `#/connexion`.

| Rôle | Boutique | PIN de démo |
|---|---|---|
| Super Admin | — | `246810` |
| Vendeur | Maison Kéba (Cosmétique) | `1111` |
| Vendeur | Atelier Dentelle (Lingerie) | `2222` |
| Vendeur | Le Jardin de la Teranga (Restaurant) | `3333` |
| Vendeur | Sandaga Céramiques (Carreaux) | `4444` |
| Vendeur | Médina Tech (Électronique) | `5555` |

**À vérifier en priorité :**

1. **Connexion** : un PIN faux affiche « Code PIN incorrect » sous le champ ; après 5 échecs, la connexion est bloquée 60 s. Le bon PIN mène à l'espace vendeur ou au panneau Super Admin.
2. **Produit (vendeur `1111`)** : *Ajouter un produit*. Enregistrez avec le formulaire vide : les erreurs s'affichent sous les champs. Ajoutez ensuite 3 photos ou plus (elles sont compressées en WebP < 500 Ko), cochez « vente en gros » (ex. lot de 12 pièces), puis enregistrez. Testez ensuite **Modifier**, **Dupliquer** et **Supprimer** (une confirmation est demandée).
3. **Vitrine** (`#/b/maison-keba`) : badge « N photos », recherche sans accents (« serum »), filtres, fiche produit (flèches ← →, Échap, balayage sur mobile), achat au détail ou en gros, refus si le stock est insuffisant, panier → **Commander sur WhatsApp** (message structuré).
4. **Facture avec cachet et signature** : onglet *Factures* → *Nouvelle facture*. Choisissez un produit, mettez une remise et des frais de livraison, cochez cachet, signature (dessinez à la souris ou au doigt) et filigrane. L'enregistrement attribue le numéro `FAC-2026-000N`. Ouvrez ensuite *Aperçu* → *Imprimer / PDF*. Pour régler le filigrane (taille, opacité, texte ou image), le cachet et le logo : *Paramètres*.
5. **Bon de livraison** : icône camion sur une facture, ou bien *Bons de livraison* → *Nouveau bon*. Remplissez l'adresse, faites signer le livreur et le client, puis enregistrez et imprimez.
6. **Thème (Super Admin `246810`)** : sous *Thème global*, choisissez un thème ou un mode. La barre « Aperçu non enregistré » apparaît ; cliquez ensuite *Enregistrer* ou *Annuler*. Créez un thème personnalisé (le contraste est vérifié). Dans *Boutiques* → *Configurer*, vous réglez le thème métier, le mode, le style, les polices, les couleurs, le forfait et les limites de photos (3 à 9), les modules et le PIN. L'aperçu se met à jour en direct.
7. **Super Admin, autres actions** : créer, suspendre ou réactiver une boutique. La suppression demande de saisir le nom de la boutique et télécharge d'abord une sauvegarde JSON. *Gérer le contenu* ouvre l'espace vendeur d'une boutique ; dans ce cas, le téléversement HD jusqu'à 50 Mo est possible sans compression. *Données* permet l'export et l'import JSON et la réinitialisation de la démo.
8. **Accessibilité** : naviguez au clavier (le premier Tab fait apparaître « Aller au catalogue »), activez « Réduire les animations » dans le système (le bandeau et le carrousel s'arrêtent), et testez le bouton soleil/lune de la vitrine (Clair → Sombre → Cyberpunk → Pastel).

## Limites restantes et recommandations pour la version serveur

- **Données locales** : tout est stocké dans le navigateur (localStorage et IndexedDB), sur un seul appareil, et le quota est d'environ 5 Mo pour les données. → Migrer vers **Cloudflare D1** (boutiques, produits, factures), **R2** (photos) et **KV** (sessions, cache de vitrine), via des **Pages Functions** (API).
- **Authentification simulée** : les PIN sont hachés en SHA-256 côté client et le cloisonnement entre boutiques est fait par l'interface. → Côté serveur, utiliser Argon2id ou bcrypt avec sel, des sessions en cookie `HttpOnly; Secure; SameSite=Strict`, une limitation de débit (Cloudflare Rate Limiting / Turnstile), un contrôle d'accès vérifié à chaque requête (`shop_id` de la session) et un journal d'audit des actions sensibles.
- **PIN de démo** : affichés sur l'écran de connexion. Désactivez l'option dans *Super Admin → Données*, puis changez tous les PIN.
- **Numérotation des factures** : le compteur est local. Plusieurs appareils pourraient donc produire le même numéro. → Utiliser une séquence transactionnelle en base. Les factures ne sont pas verrouillées après émission ; prévoir des avoirs plutôt que des modifications.
- **Stock** : la commande WhatsApp ne décrémente pas le stock. → Ajouter un module « Commandes » (statut confirmé → stock décrémenté).
- **Paiement** : Wave et Orange Money sont seulement des modes déclaratifs. → Intégrer leurs API marchandes, avec des webhooks pour marquer les factures payées.
- **Tailwind via CDN « Play »** : un avertissement en console est normal. Ce mode demande `style-src 'unsafe-inline'` et pénalise Lighthouse Performance. → Compiler Tailwind (CLI) et auto-héberger Lucide et les polices pour viser un score supérieur à 90 et une CSP sans `unsafe-inline`.
- **PDF** : il passe par l'impression du navigateur. Le rendu peut varier selon le navigateur (sur mobile, Chrome Android et Safari iOS proposent « Enregistrer en PDF »). → Générer le PDF côté serveur si besoin.
- **Multi-onglets** : les modifications se synchronisent entre onglets, mais il n'y a pas de gestion de conflits multi-utilisateurs.
- **Photos orphelines** : une image téléversée sans enregistrer reste dans IndexedDB. Le bouton *Nettoyer les photos orphelines* (Super Admin → Données) les supprime.
